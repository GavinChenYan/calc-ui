(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["user-profile-user-profile-module"],{

/***/ "./src/app/user-profile/models/index.ts":
/*!**********************************************!*\
  !*** ./src/app/user-profile/models/index.ts ***!
  \**********************************************/
/*! exports provided: PreloadedProfiles */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _profiles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profiles */ "./src/app/user-profile/models/profiles.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "PreloadedProfiles", function() { return _profiles__WEBPACK_IMPORTED_MODULE_0__["PreloadedProfiles"]; });




/***/ }),

/***/ "./src/app/user-profile/models/profiles.ts":
/*!*************************************************!*\
  !*** ./src/app/user-profile/models/profiles.ts ***!
  \*************************************************/
/*! exports provided: PreloadedProfiles */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreloadedProfiles", function() { return PreloadedProfiles; });
var userProfile0 = {
    income: 105000,
    totalAsset: 12000000,
    taxRate: 25,
    clientId: 'c122222',
    liability: 0,
    savings: 0,
    inflationRate: 2,
    expenses: 100000,
    clientName: 'Emily Petersen',
    additionalSurplus: 0,
    additionalSurplusFrequency: 'MONTHLY',
    goals: [
        {
            goalType: 'SAVING',
            goalId: '0011',
            lumpSum: 0,
            allocations: [
                {
                    allocationType: 'CURRENT',
                    finalAmount: 0,
                    costOfBorrowing: 0,
                    products: [
                        {
                            registerAccount: true,
                            productId: '0001',
                            additionalContribution: 0,
                            additionalContributionFrequency: 'MONTHLY',
                            initialContribution: 0,
                            contributionAmount: 458,
                            balance: 0,
                            accountNo: '0011-2256',
                            interestRateAcc: 5,
                            contributionLimitAcc: 0,
                            productType: 'TFSA',
                            maxAnnualContribution: 5500,
                            compoundingFrequency: 'MONTHLY',
                            minimumPayment: 0,
                            minPaymentFrequency: 'MONTHLY'
                        },
                        {
                            registerAccount: false,
                            productId: '0003',
                            additionalContribution: 0,
                            additionalContributionFrequency: 'MONTHLY',
                            initialContribution: 0,
                            contributionAmount: 138,
                            balance: 0,
                            accountNo: '0018-2256',
                            interestRateAcc: 2,
                            contributionLimitAcc: 0,
                            productType: 'SAVING',
                            maxAnnualContribution: 0,
                            compoundingFrequency: 'MONTHLY',
                            minimumPayment: 0,
                            minPaymentFrequency: 'MONTHLY'
                        }
                    ]
                }
            ],
            goalName: 'Saving for Down Payment',
            goalTargetAmount: 50000,
            goalTargetYear: 2022,
            startDate: '201812',
            completeDate: '202812'
        },
        {
            goalType: 'DEBT',
            goalId: '0012',
            lumpSum: 0,
            allocations: [
                {
                    allocationType: 'CURRENT',
                    finalAmount: 0,
                    costOfBorrowing: 0,
                    products: [
                        {
                            productId: '0004',
                            registerAccount: false,
                            accountNo: '0018-2256',
                            additionalContribution: 0,
                            additionalContributionFrequency: 'MONTHLY',
                            initialContribution: 0,
                            contributionAmount: 300,
                            balance: 10000,
                            interestRateAcc: 2,
                            contributionLimitAcc: 0,
                            productType: 'STUDENT_LOAN',
                            maxAnnualContribution: 0,
                            compoundingFrequency: 'MONTHLY',
                            minimumPayment: 0,
                            minPaymentFrequency: 'MONTHLY'
                        }
                    ]
                }
            ],
            goalName: 'Paying down Debt',
            goalTargetAmount: 10000,
            goalTargetYear: 2022,
            startDate: '201812',
            completeDate: '202812'
        }
    ]
};
var userProfile1 = {
    income: 105000,
    totalAsset: 12000000,
    taxRate: 25,
    clientId: 'c122222',
    liability: 0,
    savings: 0,
    inflationRate: 2,
    expenses: 100000,
    clientName: 'Emily Petersen',
    additionalSurplus: 0,
    additionalSurplusFrequency: 'MONTHLY',
    goals: [
        {
            goalType: 'SAVING',
            goalId: '0011',
            lumpSum: 0,
            allocations: [
                {
                    allocationType: 'CURRENT',
                    finalAmount: 0,
                    costOfBorrowing: 0,
                    products: [
                        {
                            registerAccount: true,
                            productId: '0001',
                            additionalContribution: 0,
                            additionalContributionFrequency: 'MONTHLY',
                            initialContribution: 0,
                            contributionAmount: 150,
                            balance: 0,
                            accountNo: '0011-2256',
                            interestRateAcc: 4,
                            contributionLimitAcc: 0,
                            productType: 'TFSA',
                            maxAnnualContribution: 5500,
                            compoundingFrequency: 'MONTHLY',
                            minimumPayment: 0,
                            minPaymentFrequency: 'MONTHLY'
                        },
                        {
                            registerAccount: false,
                            productId: '0003',
                            additionalContribution: 0,
                            additionalContributionFrequency: 'MONTHLY',
                            initialContribution: 0,
                            contributionAmount: 450,
                            balance: 0,
                            accountNo: '0018-2256',
                            interestRateAcc: 1,
                            contributionLimitAcc: 0,
                            productType: 'SAVING',
                            maxAnnualContribution: 0,
                            compoundingFrequency: 'MONTHLY',
                            minimumPayment: 0,
                            minPaymentFrequency: 'MONTHLY'
                        }
                    ]
                }
            ],
            goalName: 'Saving for Down Payment',
            goalTargetAmount: 30000,
            goalTargetYear: 2021,
            startDate: '201812',
            completeDate: '202112'
        },
        {
            goalType: 'DEBT',
            goalId: '0012',
            lumpSum: 0,
            allocations: [
                {
                    allocationType: 'CURRENT',
                    finalAmount: 0,
                    costOfBorrowing: 0,
                    products: [
                        {
                            productId: '0004',
                            registerAccount: false,
                            accountNo: '0018-2256',
                            additionalContribution: 200,
                            additionalContributionFrequency: 'MONTHLY',
                            initialContribution: 0,
                            contributionAmount: 200,
                            balance: 15000,
                            interestRateAcc: 7,
                            contributionLimitAcc: 0,
                            productType: 'STUDENT_LOAN',
                            maxAnnualContribution: 0,
                            compoundingFrequency: 'MONTHLY',
                            minimumPayment: 200,
                            minPaymentFrequency: 'MONTHLY'
                        }
                    ]
                }
            ],
            goalName: 'Paying down Debt',
            goalTargetAmount: 15000,
            goalTargetYear: 2020,
            startDate: '201812',
            completeDate: '202012'
        }
    ]
};
var userProfile2 = {
    income: 105000,
    totalAsset: 12000000,
    taxRate: 25,
    clientId: 'c122222',
    liability: 0,
    savings: 0,
    inflationRate: 2,
    expenses: 100000,
    clientName: 'Emily Petersen',
    additionalSurplus: 2000,
    additionalSurplusFrequency: 'MONTHLY',
    goals: [
        {
            goalType: 'SAVING',
            goalId: '0011',
            lumpSum: 0,
            allocations: [
                {
                    allocationType: 'CURRENT',
                    finalAmount: 0,
                    costOfBorrowing: 0,
                    products: [
                        {
                            registerAccount: true,
                            productId: '0001',
                            additionalContribution: 0,
                            additionalContributionFrequency: 'MONTHLY',
                            initialContribution: 0,
                            contributionAmount: 300,
                            balance: 0,
                            accountNo: '0011-2256',
                            interestRateAcc: 7,
                            contributionLimitAcc: 0,
                            productType: 'TFSA',
                            maxAnnualContribution: 5500,
                            compoundingFrequency: 'MONTHLY',
                            minimumPayment: 0,
                            minPaymentFrequency: 'MONTHLY'
                        },
                        {
                            registerAccount: false,
                            productId: '0003',
                            additionalContribution: 0,
                            additionalContributionFrequency: 'MONTHLY',
                            initialContribution: 0,
                            contributionAmount: 200,
                            balance: 0,
                            accountNo: '0018-2256',
                            interestRateAcc: 1,
                            contributionLimitAcc: 0,
                            productType: 'SAVING',
                            maxAnnualContribution: 0,
                            compoundingFrequency: 'MONTHLY',
                            minimumPayment: 0,
                            minPaymentFrequency: 'MONTHLY'
                        }
                    ]
                }
            ],
            goalName: 'Saving for Down Payment',
            goalTargetAmount: 20000,
            goalTargetYear: 2022,
            startDate: '201812',
            completeDate: '202112'
        },
        {
            goalType: 'DEBT',
            goalId: '0012',
            lumpSum: 0,
            allocations: [
                {
                    allocationType: 'CURRENT',
                    finalAmount: 0,
                    costOfBorrowing: 0,
                    products: [
                        {
                            productId: '0004',
                            registerAccount: false,
                            accountNo: '0018-2256',
                            additionalContribution: 300,
                            additionalContributionFrequency: 'MONTHLY',
                            initialContribution: 0,
                            contributionAmount: 200,
                            balance: 15000,
                            interestRateAcc: 4,
                            contributionLimitAcc: 0,
                            productType: 'STUDENT_LOAN',
                            maxAnnualContribution: 6000,
                            compoundingFrequency: 'MONTHLY',
                            minimumPayment: 200,
                            minPaymentFrequency: 'MONTHLY'
                        }
                    ]
                }
            ],
            goalName: 'Paying down Debt',
            goalTargetAmount: 15000,
            goalTargetYear: 2020,
            startDate: '201812',
            completeDate: '202012'
        }
    ]
};
var userProfile3 = {
    income: 105000,
    totalAsset: 12000000,
    taxRate: 25,
    clientId: 'c122222',
    liability: 0,
    savings: 0,
    inflationRate: 2,
    expenses: 100000,
    clientName: 'Emily Petersen',
    additionalSurplus: 0,
    additionalSurplusFrequency: 'MONTHLY',
    goals: [
        {
            goalType: 'SAVING',
            goalId: '0011',
            lumpSum: 0,
            allocations: [
                {
                    allocationType: 'CURRENT',
                    finalAmount: 0,
                    costOfBorrowing: 0,
                    products: [
                        {
                            registerAccount: true,
                            productId: '0001',
                            additionalContribution: 0,
                            additionalContributionFrequency: 'MONTHLY',
                            initialContribution: 0,
                            contributionAmount: 400,
                            balance: 0,
                            accountNo: '0011-2256',
                            interestRateAcc: 7,
                            contributionLimitAcc: 0,
                            productType: 'TFSA',
                            maxAnnualContribution: 5500,
                            compoundingFrequency: 'MONTHLY',
                            minimumPayment: 0,
                            minPaymentFrequency: 'MONTHLY'
                        },
                        {
                            registerAccount: false,
                            productId: '0003',
                            additionalContribution: 0,
                            additionalContributionFrequency: 'MONTHLY',
                            initialContribution: 0,
                            contributionAmount: 0,
                            balance: 0,
                            accountNo: '0018-2256',
                            interestRateAcc: 1,
                            contributionLimitAcc: 0,
                            productType: 'SAVING',
                            maxAnnualContribution: 0,
                            compoundingFrequency: 'MONTHLY',
                            minimumPayment: 0,
                            minPaymentFrequency: 'MONTHLY'
                        }
                    ]
                }
            ],
            goalName: 'Saving for Down Payment',
            goalTargetAmount: 20000,
            goalTargetYear: 2022,
            startDate: '201812',
            completeDate: '202212'
        },
        {
            goalType: 'DEBT',
            goalId: '0012',
            lumpSum: 0,
            allocations: [
                {
                    allocationType: 'CURRENT',
                    finalAmount: 0,
                    costOfBorrowing: 0,
                    products: [
                        {
                            productId: '0004',
                            registerAccount: false,
                            accountNo: '0018-2256',
                            additionalContribution: 600,
                            additionalContributionFrequency: 'MONTHLY',
                            initialContribution: 0,
                            contributionAmount: 200,
                            balance: 15000,
                            interestRateAcc: 7,
                            contributionLimitAcc: 0,
                            productType: 'STUDENT_LOAN',
                            maxAnnualContribution: 6000,
                            compoundingFrequency: 'MONTHLY',
                            minimumPayment: 200,
                            minPaymentFrequency: 'MONTHLY'
                        }
                    ]
                }
            ],
            goalName: 'Paying down Debt',
            goalTargetAmount: 15000,
            goalTargetYear: 2020,
            startDate: '201812',
            completeDate: '202012'
        }
    ]
};
var PreloadedProfiles = /** @class */ (function () {
    function PreloadedProfiles() {
        this.profiles = [userProfile0, userProfile1, userProfile2, userProfile3];
    }
    PreloadedProfiles.prototype.getProfile = function (index) {
        return this.profiles[index];
    };
    return PreloadedProfiles;
}());



/***/ }),

/***/ "./src/app/user-profile/services/user-profile.service.ts":
/*!***************************************************************!*\
  !*** ./src/app/user-profile/services/user-profile.service.ts ***!
  \***************************************************************/
/*! exports provided: UserProfileService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserProfileService", function() { return UserProfileService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var UserProfileService = /** @class */ (function () {
    function UserProfileService(http) {
        this.http = http;
        this.serviceEndPoint = '/goals/calculate';
    }
    UserProfileService.prototype.createUserProfile = function (req) {
        return this.http.post(this.serviceEndPoint, req, httpOptions);
    };
    UserProfileService.prototype.handleError = function (operation, result) {
        var _this = this;
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            // TODO: send the error to remote logging infrastructure
            console.error(error); // log to console instead
            // TODO: better job of transforming error for user consumption
            _this.log(operation + " failed: " + error.message);
            // Let the app keep running by returning an empty result.
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(result);
        };
    };
    /** Log a HeroService message with the MessageService */
    UserProfileService.prototype.log = function (message) {
        console.log(message);
    };
    UserProfileService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], UserProfileService);
    return UserProfileService;
}());



/***/ }),

/***/ "./src/app/user-profile/user-profile-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/user-profile/user-profile-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: UserProfileRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserProfileRoutingModule", function() { return UserProfileRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _user_profile_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-profile.component */ "./src/app/user-profile/user-profile.component.ts");


var routes = [
    {
        path: '',
        component: _user_profile_component__WEBPACK_IMPORTED_MODULE_1__["UserProfileComponent"]
    }
];
var UserProfileRoutingModule = _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes);


/***/ }),

/***/ "./src/app/user-profile/user-profile.component.html":
/*!**********************************************************!*\
  !*** ./src/app/user-profile/user-profile.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\n  <div>\n    <button mat-button (click)=\"submitInfo()\" class=\"button\" fxFlexFill>Submit Info</button>\n    <h1>Client Page</h1>\n  </div>\n  <div>\n    Preset profiles:\n    <button mat-button (click)=\"loadSelectedProfile(1)\" class=\"button\">Load Profile 1</button>\n    <button mat-button (click)=\"loadSelectedProfile(2)\" class=\"button\">Load Profile 2</button>\n    <button mat-button (click)=\"loadSelectedProfile(3)\" class=\"button\">Load Profile 3</button>\n  </div>\n  <div>\n    <mat-card>\n      <mat-card-header>\n        <div mat-card-avatar class=\"user-avatar\"></div>\n        <mat-card-title class=\"title\">Client Info</mat-card-title>\n      </mat-card-header>\n      <mat-card-content>\n        <div class=\"form-group user-profile-card\">\n          <mat-form-field class=\"form-field \"><input type=\"text\" matInput placeholder=\"Client Name\" [(ngModel)]=\"userProfile.clientName\"></mat-form-field>\n          <mat-form-field class=\"form-field \"><input type=\"number\" matInput placeholder=\"Income\" [(ngModel)]=\"userProfile.income\"></mat-form-field>\n          <mat-form-field class=\"form-field \"><input type=\"number\" matInput placeholder=\"Expenses\" [(ngModel)]=\"userProfile.expenses\"></mat-form-field>\n          <mat-form-field class=\"form-field \"><input type=\"number\" matInput placeholder=\"Savings\" [(ngModel)]=\"userProfile.savings\"></mat-form-field>\n          <mat-form-field class=\"form-field \"><input type=\"number\" matInput placeholder=\"Tax Rate\" [(ngModel)]=\"userProfile.taxRate\"><span matSuffix>%</span></mat-form-field>\n          <mat-form-field class=\"form-field \"><input type=\"number\" matInput placeholder=\"Liability\" [(ngModel)]=\"userProfile.liability\"></mat-form-field>\n          <mat-form-field class=\"form-field \"><input type=\"number\" matInput placeholder=\"Inflation Rate\" [(ngModel)]=\"userProfile.inflationRate\"></mat-form-field>\n          <mat-form-field class=\"form-field \"><input type=\"number\" matInput placeholder=\"Surplus\" [(ngModel)]=\"userProfile.additionalSurplus\"></mat-form-field>\n          <mat-form-field class=\"form-field \"><input type=\"text\" matInput placeholder=\"Frequency\" [(ngModel)]=\"userProfile.additionalSurplusFrequency\"></mat-form-field>\n        </div>\n      </mat-card-content>\n    </mat-card>\n    <mat-divider class=\"divider\"></mat-divider>\n    <!-- goals -->\n    <mat-card>\n      <mat-card-header>\n        <div mat-card-avatar class=\"user-avatar\"></div>\n        <mat-card-title class=\"title\">Goals</mat-card-title>\n      </mat-card-header>\n      <mat-card-content>\n        <div>\n          <div class=\"title\" *ngFor=\"let goal of userProfile.goals\">\n            <h3 mat-subheader>{{goal.goalType == 'SAVING' ? 'SAVINGS' : 'DEBT' }}</h3>\n             <div class=\"form-group\">\n              <mat-form-field class=\"form-field\"><input matInput placeholder=\"Goal Name\" [(ngModel)]=\"goal.goalName\"></mat-form-field>\n              <mat-form-field class=\"form-field\"><input matInput placeholder=\"Target Amount\" [(ngModel)]=\"goal.goalTargetAmount\"></mat-form-field>\n              <mat-form-field class=\"form-field\"><input matInput placeholder=\"Target Year\" [(ngModel)]=\"goal.goalTargetYear\"></mat-form-field>\n            </div>\n            <div class=\"goal-allocations\">\n              <div class=\"allocation\" *ngFor=\"let allocation of goal.allocations\">\n                <mat-divider class=\"divider\"></mat-divider>\n\n                <div class=\"goal-products\">\n                  <div class=\"title\">\n                    <h4>Products</h4>\n                  </div>\n                  <div class=\"product\" *ngFor=\"let product of allocation.products\">\n                    <div class='product-details'>\n                      <div class=\"form-field1\">\n                        <mat-form-field>\n                          <mat-select placeholder=\"Product Type\" [(ngModel)]=\"product.productType\" name=\"goal\">\n                            <mat-option *ngFor=\"let item of productTypes\" [value]=\"item.key\">\n                              {{item.value}}\n                            </mat-option>\n                          </mat-select>\n                        </mat-form-field>\n                      </div>\n                      <div class=\"form-field1\">\n\n                        <mat-form-field>\n                          <mat-select placeholder=\"Compounding Frequency\" [(ngModel)]=\"product.compoundingFrequency\"\n                            name=\"goal\">\n                            <mat-option *ngFor=\"let item of productCompounding\" [value]=\"item\">\n                              {{item}}\n                            </mat-option>\n                          </mat-select>\n                        </mat-form-field>\n                      </div>\n                    </div>\n                    <mat-form-field class=\"form-field\"><input type=\"number\" matInput placeholder=\"Contribution Amount\"[(ngModel)]=\"product.contributionAmount\"></mat-form-field>\n                    <mat-form-field class=\"form-field\"><input type=\"number\" matInput  placeholder=\"Pre Payment\" [(ngModel)]=\"product.additionalContribution\"></mat-form-field>\n                    <mat-form-field>\n                      <mat-select placeholder=\"Prepayment Frequency\" [(ngModel)]=\"product.additionalContributionFrequency\"\n                        name=\"goal\">\n                        <mat-option *ngFor=\"let item of productCompounding\" [value]=\"item\">\n                          {{item}}\n                        </mat-option>\n                      </mat-select>\n                    </mat-form-field>\n                    <mat-form-field class=\"form-field\"><input type=\"number\" matInput  placeholder=\"Minimum Payment\" [(ngModel)]=\"product.minimumPayment\"></mat-form-field>\n                    <mat-form-field class=\"form-field\"><input type=\"text\" matInput  placeholder=\"Min.Payment Frequency\" [(ngModel)]=\"product.minPaymentFrequency\"></mat-form-field>\n                    <mat-form-field class=\"form-field\"><input type=\"number\" matInput placeholder=\"Initial Contribution Amount\"[(ngModel)]=\"product.initialContribution\"></mat-form-field>\n                    <mat-form-field class=\"form-field\"><input type=\"number\" matInput placeholder=\"Balance\" [(ngModel)]=\"product.balance\"></mat-form-field>\n                    <mat-form-field class=\"form-field\"><input type=\"text\" matInput placeholder=\"Account No\" [(ngModel)]=\"product.accountNo\"></mat-form-field>\n                    <mat-form-field class=\"form-field\"><input type=\"number\" matInput placeholder=\"Interest Rate Acc.\" [(ngModel)]=\"product.interestRateAcc\"><span matSuffix>%</span></mat-form-field>\n                    <mat-form-field class=\"form-field\"><input type=\"number\" matInput placeholder=\"Contribution Limit Acc.\" [(ngModel)]=\"product.contributionLimitAcc\"></mat-form-field>\n                    <mat-form-field class=\"form-field\"><input type=\"number\" matInput placeholder=\"Max. Annual Contribution Limit Acc.\" [(ngModel)]=\"product.maxAnnualContribution\"></mat-form-field>\n                    <mat-divider class=\"divider\"></mat-divider>\n                  </div>\n                </div>\n              </div>\n            </div>\n          </div>\n        </div>\n      </mat-card-content>\n    </mat-card>\n    <button mat-button (click)=\"submitInfo()\" class=\"button\" fxFlexFill>Submit Info</button>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/user-profile/user-profile.component.scss":
/*!**********************************************************!*\
  !*** ./src/app/user-profile/user-profile.component.scss ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "* {\n  margin: 0;\n  max-width: 1300px;\n  padding: 10px;\n  box-sizing: border-box; }\n\n.clientmat {\n  display: flex; }\n\n.user-avatar {\n  background-image: url(\"http://localhost:4200/assets/images/business-woman.svg\");\n  background-size: cover; }\n\n.user-profile-card {\n  background-color: #f7f7f7; }\n\n.goal-avatar {\n  background-image: url(\"http://localhost:4200/assets/images/baseline-more-horiz-24px.svg\");\n  background-size: cover; }\n\n.form-group {\n  padding: 0;\n  margin: 0;\n  list-style: none;\n  display: -webkit-flex;\n  justify-content: space-around;\n  flex-flow: row wrap;\n  flex-direction: row-reverse;\n  flex: 1; }\n\n.form-field {\n  padding: 10px;\n  text-align: center;\n  width: 150px;\n  flex-flow: wrap;\n  justify-content: space-between; }\n\n.product {\n  align-items: flex-start; }\n\n.form-field1 {\n  padding: 10px;\n  font-weight: bold;\n  text-align: center;\n  width: 150px;\n  justify-content: flex-start;\n  align-items: flex-start; }\n\n.divider {\n  padding: 10px; }\n\n.product-details {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-around;\n  padding: 15px;\n  margin-bottom: 25px;\n  justify-content: flex-start; }\n\n.product-details div {\n  padding: 5px;\n  font-family: verdana;\n  font-size: 12px;\n  text-align: center;\n  color: #494747;\n  flex-basis: 33%; }\n\n.title {\n  background-color: #f7f7f7; }\n"

/***/ }),

/***/ "./src/app/user-profile/user-profile.component.ts":
/*!********************************************************!*\
  !*** ./src/app/user-profile/user-profile.component.ts ***!
  \********************************************************/
/*! exports provided: KeyValueModel, UserProfileComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "KeyValueModel", function() { return KeyValueModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserProfileComponent", function() { return UserProfileComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _models__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./models */ "./src/app/user-profile/models/index.ts");
/* harmony import */ var _services_user_profile_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services/user-profile.service */ "./src/app/user-profile/services/user-profile.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shared_services_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../shared/services/data.service */ "./src/app/shared/services/data.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var KeyValueModel = /** @class */ (function () {
    function KeyValueModel() {
    }
    return KeyValueModel;
}());

var UserProfileComponent = /** @class */ (function () {
    function UserProfileComponent(userProfileService, router, data) {
        this.userProfileService = userProfileService;
        this.router = router;
        this.data = data;
        this.preloadedProfiles = new _models__WEBPACK_IMPORTED_MODULE_1__["PreloadedProfiles"]();
        // productTypes: string[] = ['RRSP', 'TFSA', 'RESP', 'SAVING', 'STUDENT_LOAN', 'LINE_OF_CREDIT', 'MORTGAGE'];
        this.productTypes = [
            { key: 'RRSP', value: 'RRSP' },
            { key: 'TFSA', value: 'TFSA' },
            { key: 'RESP', value: 'RESP' },
            { key: 'SAVING', value: 'SAVINGS' },
            { key: 'STUDENT_LOAN', value: 'STUDENT_LOAN' },
            // { key: 'LINE_OF_CREDIT', value: 'LINE_OF_CREDIT' },
            { key: 'MORTGAGE', value: 'MORTGAGE' }
        ];
        this.productCompounding = ['NA', 'ONE_TIME', 'YEARLY', 'SEMI_YEARLY', 'MONTHLY', 'BI_WEEKLY', 'WEEKLY', 'DAILY'];
    }
    UserProfileComponent.prototype.ngOnInit = function () {
        this.loadSelectedProfile(0);
    };
    UserProfileComponent.prototype.loadSelectedProfile = function (selectedProfile) {
        this.userProfile = this.preloadedProfiles.getProfile(selectedProfile);
    };
    UserProfileComponent.prototype.submitInfo = function () {
        var _this = this;
        this.userProfileService.createUserProfile(this.userProfile).subscribe(function (data) {
            _this.data.changeMessage(data);
            _this.router.navigate(['/goal-playground']);
        });
    };
    UserProfileComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-user-profile',
            template: __webpack_require__(/*! ./user-profile.component.html */ "./src/app/user-profile/user-profile.component.html"),
            styles: [__webpack_require__(/*! ./user-profile.component.scss */ "./src/app/user-profile/user-profile.component.scss")]
        }),
        __metadata("design:paramtypes", [_services_user_profile_service__WEBPACK_IMPORTED_MODULE_2__["UserProfileService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _shared_services_data_service__WEBPACK_IMPORTED_MODULE_4__["DataService"]])
    ], UserProfileComponent);
    return UserProfileComponent;
}());



/***/ }),

/***/ "./src/app/user-profile/user-profile.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/user-profile/user-profile.module.ts ***!
  \*****************************************************/
/*! exports provided: UserProfileModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserProfileModule", function() { return UserProfileModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _user_profile_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./user-profile.component */ "./src/app/user-profile/user-profile.component.ts");
/* harmony import */ var _user_profile_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./user-profile-routing.module */ "./src/app/user-profile/user-profile-routing.module.ts");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _angular_material_slider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/slider */ "./node_modules/@angular/material/esm5/slider.es5.js");
/* harmony import */ var _material_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../material.module */ "./src/app/material.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};









var UserProfileModule = /** @class */ (function () {
    function UserProfileModule() {
    }
    UserProfileModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _user_profile_routing_module__WEBPACK_IMPORTED_MODULE_3__["UserProfileRoutingModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_4__["FlexLayoutModule"],
                _material_module__WEBPACK_IMPORTED_MODULE_6__["MaterialComponentsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_8__["HttpClientModule"],
                _angular_material_slider__WEBPACK_IMPORTED_MODULE_5__["MatSliderModule"]
            ],
            declarations: [
                _user_profile_component__WEBPACK_IMPORTED_MODULE_2__["UserProfileComponent"]
            ]
        })
    ], UserProfileModule);
    return UserProfileModule;
}());



/***/ })

}]);
//# sourceMappingURL=user-profile-user-profile-module.js.map