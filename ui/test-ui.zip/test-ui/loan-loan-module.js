(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["loan-loan-module"],{

/***/ "./src/app/loan/loan-calculator/loan-calculator.component.css":
/*!********************************************************************!*\
  !*** ./src/app/loan/loan-calculator/loan-calculator.component.css ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".mat-card-content {\n    font-size: 16px;\n    \n}\n.mat-card-content.div {\n    padding-bottom: 5px;\n    text-align: left;\n}\n.mat-card-title {\n    font-size: 18px;\n}\ndiv.scenario-labels {\n  padding: 15px 5px;\n}\n.offset-top {\n  padding-top: 67px;\n}\ndiv.custom-padding {\n  padding-top: 13px;\n  padding-left: 5px;\n}\n"

/***/ }),

/***/ "./src/app/loan/loan-calculator/loan-calculator.component.html":
/*!*********************************************************************!*\
  !*** ./src/app/loan/loan-calculator/loan-calculator.component.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-horizontal-stepper>\n  <mat-step label=\"Enter Goal\">\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start stretch\" fxLayoutGap>\n      <div fxLayout=\"row\" fxFill fxLayoutAlign=\"space-around\" fxLayoutGap fxFlex=\"80%\">\n\n        <app-loan-scenario-inputs [scenarioId]=\"0\" [toComputeOptimal]=\"true\"></app-loan-scenario-inputs>\n\n        <app-loan-scenario-inputs [scenarioId]=\"1\"></app-loan-scenario-inputs>\n\n        <app-loan-scenario-inputs [scenarioId]=\"2\"></app-loan-scenario-inputs>\n      </div>\n      <div>\n        <br>\n        <button mat-button matStepperNext (click)=\"calculate()\">Calculate</button>\n      </div>\n    </div>\n  </mat-step>\n\n  <mat-step label=\"Your Scenarios\">\n      <div fxLayout=\"row\" fxLayoutAlign=\"space-evenly start\" fxLayoutGap>\n        <div fxLayout=\"column\" fxLayoutGap fxLayoutAlign=\"center\" class=\"offset-top\">\n          <div class=\"scenario-labels\">\n            <span>Outstanding Balance</span>\n          </div>\n          <div class=\"scenario-labels\">\n            <span>Annual Interest Rate</span>\n          </div>\n          <div class=\"scenario-labels\">\n            <span>Contribution</span>\n          </div>\n          <div class=\"scenario-labels\">\n              <span>Additional Contribution</span>\n            </div>\n          <div class=\"scenario-labels\">\n            <span >Contribution Frequency</span>\n          </div>\n          <div class=\"scenario-labels\">\n            <span>Repayment Time</span>\n          </div>\n          <div class=\"scenario-labels\">\n            <span>Cost of Borrowing</span>\n          </div>\n        </div>\n        <ng-container *ngIf=\"results\">\n          <app-loan-scenario-result\n            *ngFor=\"let request of loansInputRequest; let i = index\"\n            [scenarioResult]=\"results[i]\"\n            [scenarioRequest]=\"request\"\n            (selectedScenarioResult)=\"selectScenarioResult($event)\">\n          </app-loan-scenario-result>\n        </ng-container>\n      </div>\n\n      <div>\n        <br>\n        <button mat-button matStepperPrevious>Back to Update Scenarios</button>\n      </div>\n  </mat-step>\n  <mat-step label=\"Schedules For Your Scenarios\">\n    \n    <app-loan-repayment-schedule *ngIf=\"scheduleData\" \n      [schedules]=\"scheduleData.schedule\" \n      [scheduledData]=\"scheduleData\">\n    </app-loan-repayment-schedule>\n\n    <div>\n      <br>\n      <button mat-button matStepperPrevious>Back to Scenario Plans</button>\n    </div>\n  </mat-step>\n</mat-horizontal-stepper>\n"

/***/ }),

/***/ "./src/app/loan/loan-calculator/loan-calculator.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/loan/loan-calculator/loan-calculator.component.ts ***!
  \*******************************************************************/
/*! exports provided: LoanCalculatorComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanCalculatorComponent", function() { return LoanCalculatorComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _loan_scenario_inputs_loan_scenario_inputs_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../loan-scenario-inputs/loan-scenario-inputs.component */ "./src/app/loan/loan-scenario-inputs/loan-scenario-inputs.component.ts");
/* harmony import */ var _services_loan_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/loan-service.service */ "./src/app/loan/services/loan-service.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var LoanCalculatorComponent = /** @class */ (function () {
    function LoanCalculatorComponent(service) {
        this.service = service;
    }
    LoanCalculatorComponent.prototype.calculate = function () {
        var _this = this;
        this.loansInputRequest = [].concat.apply([], this.loanScenarioInputsList.map(function (loanScenarioInputs) { return loanScenarioInputs.prepareScenarioInputsList(); }));
        this.service.calculate(this.loansInputRequest).subscribe(function (data) {
            _this.results = data;
        });
    };
    LoanCalculatorComponent.prototype.selectScenarioResult = function (result) {
        this.scheduleData = result['scenario'];
        this.scheduleTitle = result['title'];
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChildren"])(_loan_scenario_inputs_loan_scenario_inputs_component__WEBPACK_IMPORTED_MODULE_1__["LoanScenarioInputsComponent"]),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["QueryList"])
    ], LoanCalculatorComponent.prototype, "loanScenarioInputsList", void 0);
    LoanCalculatorComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-loan-calculator',
            template: __webpack_require__(/*! ./loan-calculator.component.html */ "./src/app/loan/loan-calculator/loan-calculator.component.html"),
            styles: [__webpack_require__(/*! ./loan-calculator.component.css */ "./src/app/loan/loan-calculator/loan-calculator.component.css")]
        }),
        __metadata("design:paramtypes", [_services_loan_service_service__WEBPACK_IMPORTED_MODULE_2__["LoanService"]])
    ], LoanCalculatorComponent);
    return LoanCalculatorComponent;
}());



/***/ }),

/***/ "./src/app/loan/loan-repayment-schedule/loan-repayment-schedule.component.css":
/*!************************************************************************************!*\
  !*** ./src/app/loan/loan-repayment-schedule/loan-repayment-schedule.component.css ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/loan/loan-repayment-schedule/loan-repayment-schedule.component.html":
/*!*************************************************************************************!*\
  !*** ./src/app/loan/loan-repayment-schedule/loan-repayment-schedule.component.html ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-card>\n    <h3>Current Scenarios</h3>\n    <table>\n      <tr><td class=\"result-title-cell\">Repayment Time:</td><td>\n          <span>{{ scheduledData?.schedule?.length}} Months</span>\n      </td></tr>\n      <tr><td class=\"result-title-cell\">Cost of Borrowing ($):</td><td>  ${{scheduledData?.costOfBorrowing | number:'1.0-0'}}</td></tr>\n\n    </table>\n</mat-card>\n\n<mat-card>\n    <h3>Result Schedules</h3>\n    <table mat-table [dataSource]=\"schedules\" class=\"test-full-width\">\n\n        <!--- Note that these columns can be defined in any order.\n              The actual rendered columns are set as a property on the row definition\" -->\n\n        <!-- Position Column -->\n        <ng-container matColumnDef=\"year\">\n          <th mat-header-cell *matHeaderCellDef> Period </th>\n          <td class=\"result-cell\" mat-cell *matCellDef=\"let record; let i = index\">Month {{i + 1}}</td>\n        </ng-container>\n\n        <!-- Weight Column -->\n        <ng-container matColumnDef=\"Contribution\">\n          <th mat-header-cell *matHeaderCellDef> Contribution </th>\n          <td class=\"result-cell\" mat-cell *matCellDef=\"let detailObj\">\n\n            <loan-schedule-detail *ngIf=\"detailObj.scheduleDetails\" [scheduleDetail]=\"detailObj.scheduleDetails\"></loan-schedule-detail>\n\n          </td>\n        </ng-container>\n\n        <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n        <tr mat-row *matRowDef=\"let row; columns: displayedColumns;\"></tr>\n      </table>\n</mat-card>\n"

/***/ }),

/***/ "./src/app/loan/loan-repayment-schedule/loan-repayment-schedule.component.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/loan/loan-repayment-schedule/loan-repayment-schedule.component.ts ***!
  \***********************************************************************************/
/*! exports provided: LoanRepaymentScheduleComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanRepaymentScheduleComponent", function() { return LoanRepaymentScheduleComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var LoanRepaymentScheduleComponent = /** @class */ (function () {
    function LoanRepaymentScheduleComponent() {
        this.displayedColumns = ['year', 'Contribution'];
    }
    LoanRepaymentScheduleComponent.prototype.ngOnInit = function () {
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], LoanRepaymentScheduleComponent.prototype, "scheduledData", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], LoanRepaymentScheduleComponent.prototype, "schedules", void 0);
    LoanRepaymentScheduleComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-loan-repayment-schedule',
            template: __webpack_require__(/*! ./loan-repayment-schedule.component.html */ "./src/app/loan/loan-repayment-schedule/loan-repayment-schedule.component.html"),
            styles: [__webpack_require__(/*! ./loan-repayment-schedule.component.css */ "./src/app/loan/loan-repayment-schedule/loan-repayment-schedule.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], LoanRepaymentScheduleComponent);
    return LoanRepaymentScheduleComponent;
}());



/***/ }),

/***/ "./src/app/loan/loan-routing.module.ts":
/*!*********************************************!*\
  !*** ./src/app/loan/loan-routing.module.ts ***!
  \*********************************************/
/*! exports provided: LoanRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanRoutingModule", function() { return LoanRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _loan_calculator_loan_calculator_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./loan-calculator/loan-calculator.component */ "./src/app/loan/loan-calculator/loan-calculator.component.ts");


var routes = [
    {
        path: '',
        component: _loan_calculator_loan_calculator_component__WEBPACK_IMPORTED_MODULE_1__["LoanCalculatorComponent"]
    }
];
var LoanRoutingModule = _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes);


/***/ }),

/***/ "./src/app/loan/loan-scenario-inputs/loan-scenario-inputs.component.css":
/*!******************************************************************************!*\
  !*** ./src/app/loan/loan-scenario-inputs/loan-scenario-inputs.component.css ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/loan/loan-scenario-inputs/loan-scenario-inputs.component.html":
/*!*******************************************************************************!*\
  !*** ./src/app/loan/loan-scenario-inputs/loan-scenario-inputs.component.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-card>\n\n  <mat-card-header>\n    <mat-card-title>{{scenarioTitle}}</mat-card-title>\n  </mat-card-header>\n  <form [formGroup]=\"scenarioForm\" (ngSubmit)=\"onSubmit()\">\n    <mat-form-field class=\"test-full-width\">\n      <mat-label>Loan Type</mat-label>\n      <input matInput placeholder=\"Loan Type\" type=\"string\" formControlName=\"loanType\">\n    </mat-form-field>\n\n    <mat-form-field class=\"test-full-width\">\n      <mat-label>Outstanding Loan Balance</mat-label>\n      <span matPrefix>$&nbsp;</span>\n      <input matInput placeholder=\"Loan Balance Amount\" type=\"number\" formControlName=\"initialBalance\">\n    </mat-form-field>\n\n    <mat-form-field class=\"test-full-width\" appearance=\"fill\">\n      <mat-label>Annual Interest Rate</mat-label>\n      <input matInput placeholder=\"Annual Interest Rate\" type=\"number\" formControlName=\"annualInterestRate\">\n      <span matSuffix>%&nbsp;</span>\n    </mat-form-field>\n\n    <mat-form-field class=\"test-full-width\">\n      <mat-select placeholder=\"Interest Rate Compounding\" formControlName=\"interestRateCompoundingFrequency\">\n        <mat-option *ngFor=\"let option of compoundRateOptions\" [value]=\"option.value\">\n          {{ option.viewValue }}\n        </mat-option>\n      </mat-select>\n    </mat-form-field>\n\n    <!-->mat-form-field class=\"test-full-width\">\n      <mat-label>Initial Contribution Additional Principal</mat-label>\n      <span matPrefix>$&nbsp;</span>\n      <input matInput placeholder=\"Initial Contribution\" type=\"number\" formControlName=\"initialContribution\">\n    </mat-form-field-->\n\n    <mat-form-field class=\"test-full-width\">\n      <mat-label>Contribution</mat-label>\n      <span matPrefix>$&nbsp;</span>\n      <input matInput placeholder=\"Periodic Contribution\" type=\"number\" formControlName=\"periodicContribution\">\n    </mat-form-field>\n\n    <mat-form-field class=\"test-full-width\">\n        <mat-label>Additional Contribution</mat-label>\n        <span matPrefix>$&nbsp;</span>\n        <input matInput placeholder=\"Additional Contribution\" type=\"number\" formControlName=\"additionalContribution\">\n      </mat-form-field>\n\n    <mat-form-field class=\"test-full-width\">\n      <mat-select placeholder=\"Contribution Frequency\" formControlName=\"contributionFrequency\">\n        <mat-option *ngFor=\"let option of contributionFreqOptions\" [value]=\"option.value\">\n          {{ option.viewValue }}\n        </mat-option>\n      </mat-select>\n    </mat-form-field>\n\n    <mat-form-field class=\"test-full-width\" appearance=\"fill\">\n      <mat-label>Min Annual Contribution</mat-label>\n      <span matPrefix>$&nbsp;</span>\n      <input matInput placeholder=\"Min Periodic Contribution\" type=\"number\" formControlName=\"minAnnualContribution\">\n    </mat-form-field>\n\n    <mat-form-field class=\"test-full-width\" appearance=\"fill\">\n      <mat-label>Max Annual Contribution</mat-label>\n      <span matPrefix>$&nbsp;</span>\n      <input matInput placeholder=\"Max Periodic Contribution\" type=\"number\" formControlName=\"maxAnnualContribution\">\n    </mat-form-field>\n\n    <mat-form-field class=\"test-full-width\" appearance=\"fill\">\n      <mat-label>Loan Maturity Year (YYYY)</mat-label>\n      <input matInput [matDatepicker]=\"picker\" formControlName=\"goalTargetYear\" placeholder=\"Choose a target year (YYYY)\">\n      <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\n      <mat-datepicker #picker startView=\"multi-year\" (yearSelected)=\"chosenYearHandler($event, picker)\"></mat-datepicker>\n    </mat-form-field>\n  </form>\n</mat-card>"

/***/ }),

/***/ "./src/app/loan/loan-scenario-inputs/loan-scenario-inputs.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/loan/loan-scenario-inputs/loan-scenario-inputs.component.ts ***!
  \*****************************************************************************/
/*! exports provided: MY_FORMATS, LoanScenarioInputsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MY_FORMATS", function() { return MY_FORMATS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanScenarioInputsComponent", function() { return LoanScenarioInputsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material-moment-adapter */ "./node_modules/@angular/material-moment-adapter/esm5/material-moment-adapter.es5.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var __assign = (undefined && undefined.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var MY_FORMATS = {
    parse: {
        dateInput: 'YYYY',
    },
    display: {
        dateInput: 'YYYY',
        monthYearLabel: 'YYYY',
        dateA11yLabel: 'LL',
        monthYearA11yLabel: 'YYYY',
    },
};
var LoanScenarioInputsComponent = /** @class */ (function () {
    function LoanScenarioInputsComponent(formBuilder) {
        this.formBuilder = formBuilder;
        this.toComputeOptimal = false;
        this.compoundRateOptions = [{ value: 'MONTHLY', viewValue: 'MONTHLY' }];
        this.contributionFreqOptions = [{ value: 'MONTHLY', viewValue: 'MONTHLY' }];
    }
    LoanScenarioInputsComponent.prototype.ngOnInit = function () {
        this.scenarioForm = this.formBuilder.group({
            loanType: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('STUDENT LOAN'),
            initialBalance: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](500000),
            annualInterestRate: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](5),
            interestRateCompoundingFrequency: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.compoundRateOptions[0].value),
            // initialContribution: new FormControl(0),
            periodicContribution: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](10000),
            additionalContribution: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](0),
            contributionFrequency: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.compoundRateOptions[0].value),
            minAnnualContribution: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](10),
            maxAnnualContribution: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](2000),
            goalTargetYear: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](moment__WEBPACK_IMPORTED_MODULE_1__().year(2022))
        });
        this.scenarioTitle = '';
        if (this.scenarioId === 0) {
            this.scenarioTitle += 'Current Scenario';
        }
        else {
            this.scenarioTitle += 'Alternative Scenario ' + this.scenarioId;
        }
    };
    LoanScenarioInputsComponent.prototype.chosenYearHandler = function (normalizedYear, datepicker) {
        this.scenarioForm.controls['goalTargetYear'].setValue(normalizedYear.toISOString());
        datepicker.close();
    };
    LoanScenarioInputsComponent.prototype.prepareScenarioInputsList = function () {
        this.loanInput = __assign({}, this.scenarioForm.value);
        this.loanInput.id = this.scenarioId;
        var loanScenarioList = [];
        this.loanInput.goalTargetYear = moment__WEBPACK_IMPORTED_MODULE_1__(this.loanInput.goalTargetYear).format('YYYY-MM-DD');
        loanScenarioList.push(this.loanInput);
        if (this.toComputeOptimal) {
            var loanInputsToComputeOptimalSolution = Object.assign({}, this.loanInput);
            loanInputsToComputeOptimalSolution.computeOptimalSolution = true;
            loanScenarioList.push(loanInputsToComputeOptimalSolution);
        }
        return loanScenarioList;
    };
    LoanScenarioInputsComponent.prototype.onSubmit = function () {
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Boolean)
    ], LoanScenarioInputsComponent.prototype, "toComputeOptimal", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Number)
    ], LoanScenarioInputsComponent.prototype, "scenarioId", void 0);
    LoanScenarioInputsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-loan-scenario-inputs',
            template: __webpack_require__(/*! ./loan-scenario-inputs.component.html */ "./src/app/loan/loan-scenario-inputs/loan-scenario-inputs.component.html"),
            styles: [__webpack_require__(/*! ./loan-scenario-inputs.component.css */ "./src/app/loan/loan-scenario-inputs/loan-scenario-inputs.component.css")],
            providers: [
                { provide: _angular_material__WEBPACK_IMPORTED_MODULE_3__["DateAdapter"], useClass: _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_2__["MomentDateAdapter"], deps: [_angular_material__WEBPACK_IMPORTED_MODULE_3__["MAT_DATE_LOCALE"]] },
                { provide: _angular_material__WEBPACK_IMPORTED_MODULE_3__["MAT_DATE_FORMATS"], useValue: MY_FORMATS },
            ],
        }),
        __metadata("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]])
    ], LoanScenarioInputsComponent);
    return LoanScenarioInputsComponent;
}());



/***/ }),

/***/ "./src/app/loan/loan-scenario-result/loan-scenario-result.component.css":
/*!******************************************************************************!*\
  !*** ./src/app/loan/loan-scenario-result/loan-scenario-result.component.css ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".light-border {\n  border: solid black 1px;\n}\n\ndiv {\n  padding: 15px 5px;\n}\n"

/***/ }),

/***/ "./src/app/loan/loan-scenario-result/loan-scenario-result.component.html":
/*!*******************************************************************************!*\
  !*** ./src/app/loan/loan-scenario-result/loan-scenario-result.component.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<button mat-button matStepperNext (click)=\"select()\"><span>{{scenarioTitle}}</span></button>\n<div fxLayout=\"row\" fxLayoutGap=\"100px\">\n  <div fxLayout=\"column\" fxLayoutAlign=\"space-around start\" fxLayoutGap class=\"light-border\">\n    <div>\n      <span>{{scenarioResult.initialBalance | currency}}</span>\n    </div>\n    <div>\n      <span>{{scenarioResult.annualInterestRate | percent :'1.2-2'}}</span>\n    </div>\n    <div>\n      <span>{{scenarioResult.periodicContribution | currency}}</span>\n    </div>\n    <div>\n        <span>{{scenarioResult.additionalContribution | currency}}</span>\n      </div>\n    <div>\n      <span>{{scenarioResult.contributionFrequency}}</span>\n    </div>\n    <div>\n      <span>{{ scenarioResult?.schedule?.length || 0}}</span>\n      <span> {{ displayFrequency }} </span>\n    </div>\n    <div>\n      <span>{{scenarioResult.costOfBorrowing | currency}}</span>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/loan/loan-scenario-result/loan-scenario-result.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/loan/loan-scenario-result/loan-scenario-result.component.ts ***!
  \*****************************************************************************/
/*! exports provided: LoanScenarioResultComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanScenarioResultComponent", function() { return LoanScenarioResultComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _models_loan_scenario_response__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../models/loan-scenario-response */ "./src/app/loan/models/loan-scenario-response.ts");
/* harmony import */ var _models_loan_scenario_request__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../models/loan-scenario-request */ "./src/app/loan/models/loan-scenario-request.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var contributionFrequencyEnum;
(function (contributionFrequencyEnum) {
    contributionFrequencyEnum["MONTHLY"] = "MONTHS";
})(contributionFrequencyEnum || (contributionFrequencyEnum = {}));
var LoanScenarioResultComponent = /** @class */ (function () {
    function LoanScenarioResultComponent() {
        this.selectedScenarioResult = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.Math = Math;
    }
    LoanScenarioResultComponent.prototype.ngOnInit = function () {
        if (this.scenarioResult.id === 0) {
            this.scenarioTitle = 'Current Scenario';
        }
        else {
            this.scenarioTitle = 'Alternative Scenario ' + this.scenarioResult.id;
        }
        if (this.scenarioRequest.computeOptimalSolution) {
            this.scenarioTitle = 'Optimal Solution';
        }
        this.displayFrequency = contributionFrequencyEnum["" + this.scenarioRequest.contributionFrequency];
    };
    LoanScenarioResultComponent.prototype.select = function () {
        this.selectedScenarioResult.emit({ scenario: this.scenarioResult, title: this.scenarioTitle });
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", _models_loan_scenario_response__WEBPACK_IMPORTED_MODULE_1__["LoanScenarioResponse"])
    ], LoanScenarioResultComponent.prototype, "scenarioResult", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", _models_loan_scenario_request__WEBPACK_IMPORTED_MODULE_2__["LoanScenarioRequest"])
    ], LoanScenarioResultComponent.prototype, "scenarioRequest", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], LoanScenarioResultComponent.prototype, "selectedScenarioResult", void 0);
    LoanScenarioResultComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-loan-scenario-result',
            template: __webpack_require__(/*! ./loan-scenario-result.component.html */ "./src/app/loan/loan-scenario-result/loan-scenario-result.component.html"),
            styles: [__webpack_require__(/*! ./loan-scenario-result.component.css */ "./src/app/loan/loan-scenario-result/loan-scenario-result.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], LoanScenarioResultComponent);
    return LoanScenarioResultComponent;
}());



/***/ }),

/***/ "./src/app/loan/loan-schedule-detail/loan-schedule-detail.component.css":
/*!******************************************************************************!*\
  !*** ./src/app/loan/loan-schedule-detail/loan-schedule-detail.component.css ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/loan/loan-schedule-detail/loan-schedule-detail.component.html":
/*!*******************************************************************************!*\
  !*** ./src/app/loan/loan-schedule-detail/loan-schedule-detail.component.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap fxFlex=\"30%\">\n  <!-- Starting balance-->\n  <div fxLayout=\"row\" fxFill fxLayoutAlign=\"center end\">\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\">\n      <span>Start of Period Debt:</span>\n    </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\">\n      <span>{{scheduleDetail.startingBalance | currency}}</span>\n    </div>\n  </div>\n  <!-- Additional Contribution-->\n  <div fxLayout=\"row\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>Additional Contribution:</span>\n    </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>{{scheduleDetail.prepayment | currency}}</span>\n    </div>\n  </div>\n  <!-- remainingPrincipal-->\n  <div fxLayout=\"row\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>Remaining Principal:</span>\n    </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>{{scheduleDetail.remainingPrincipal | currency}}</span>\n    </div>\n  </div>\n  <!-- contribution-->\n  <div fxLayout=\"row\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>Payment(End of Period):</span>\n    </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>{{scheduleDetail.payment | currency}}</span>\n    </div>\n  </div>\n  <!-- interest-->\n  <div fxLayout=\"row\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>Principal:</span>\n    </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>{{scheduleDetail.principal | currency}}</span>\n    </div>\n  </div>\n\n  <div fxLayout=\"row\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>Interest:</span>\n    </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>{{scheduleDetail.interest | currency}}</span>\n    </div>\n  </div>\n  <!-- Ending balance-->\n  <div fxLayout=\"row\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>Ending of Period Debt:</span>\n    </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>{{scheduleDetail.endingBalance | currency}}</span>\n    </div>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/loan/loan-schedule-detail/loan-schedule-detail.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/loan/loan-schedule-detail/loan-schedule-detail.component.ts ***!
  \*****************************************************************************/
/*! exports provided: LoanScheduleDetailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanScheduleDetailComponent", function() { return LoanScheduleDetailComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var LoanScheduleDetailComponent = /** @class */ (function () {
    //sc = new MatTableDataSource(this.scheduledData.schedule);
    function LoanScheduleDetailComponent() {
    }
    LoanScheduleDetailComponent.prototype.ngOnInit = function () {
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], LoanScheduleDetailComponent.prototype, "scheduleDetail", void 0);
    LoanScheduleDetailComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'loan-schedule-detail',
            template: __webpack_require__(/*! ./loan-schedule-detail.component.html */ "./src/app/loan/loan-schedule-detail/loan-schedule-detail.component.html"),
            styles: [__webpack_require__(/*! ./loan-schedule-detail.component.css */ "./src/app/loan/loan-schedule-detail/loan-schedule-detail.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], LoanScheduleDetailComponent);
    return LoanScheduleDetailComponent;
}());



/***/ }),

/***/ "./src/app/loan/loan.module.ts":
/*!*************************************!*\
  !*** ./src/app/loan/loan.module.ts ***!
  \*************************************/
/*! exports provided: LoanModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanModule", function() { return LoanModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _material_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../material.module */ "./src/app/material.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _loan_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./loan-routing.module */ "./src/app/loan/loan-routing.module.ts");
/* harmony import */ var _loan_calculator_loan_calculator_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./loan-calculator/loan-calculator.component */ "./src/app/loan/loan-calculator/loan-calculator.component.ts");
/* harmony import */ var _loan_scenario_result_loan_scenario_result_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./loan-scenario-result/loan-scenario-result.component */ "./src/app/loan/loan-scenario-result/loan-scenario-result.component.ts");
/* harmony import */ var _loan_scenario_inputs_loan_scenario_inputs_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./loan-scenario-inputs/loan-scenario-inputs.component */ "./src/app/loan/loan-scenario-inputs/loan-scenario-inputs.component.ts");
/* harmony import */ var _loan_repayment_schedule_loan_repayment_schedule_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./loan-repayment-schedule/loan-repayment-schedule.component */ "./src/app/loan/loan-repayment-schedule/loan-repayment-schedule.component.ts");
/* harmony import */ var _loan_schedule_detail_loan_schedule_detail_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./loan-schedule-detail/loan-schedule-detail.component */ "./src/app/loan/loan-schedule-detail/loan-schedule-detail.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};












var LoanModule = /** @class */ (function () {
    function LoanModule() {
    }
    LoanModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatInputModule"],
                _material_module__WEBPACK_IMPORTED_MODULE_2__["MaterialComponentsModule"],
                _loan_routing_module__WEBPACK_IMPORTED_MODULE_6__["LoanRoutingModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_5__["FlexLayoutModule"]
            ],
            declarations: [
                _loan_calculator_loan_calculator_component__WEBPACK_IMPORTED_MODULE_7__["LoanCalculatorComponent"],
                _loan_scenario_result_loan_scenario_result_component__WEBPACK_IMPORTED_MODULE_8__["LoanScenarioResultComponent"],
                _loan_scenario_inputs_loan_scenario_inputs_component__WEBPACK_IMPORTED_MODULE_9__["LoanScenarioInputsComponent"],
                _loan_repayment_schedule_loan_repayment_schedule_component__WEBPACK_IMPORTED_MODULE_10__["LoanRepaymentScheduleComponent"],
                _loan_schedule_detail_loan_schedule_detail_component__WEBPACK_IMPORTED_MODULE_11__["LoanScheduleDetailComponent"]
            ],
            exports: [
                _loan_calculator_loan_calculator_component__WEBPACK_IMPORTED_MODULE_7__["LoanCalculatorComponent"]
            ]
        })
    ], LoanModule);
    return LoanModule;
}());



/***/ }),

/***/ "./src/app/loan/models/loan-scenario-request.ts":
/*!******************************************************!*\
  !*** ./src/app/loan/models/loan-scenario-request.ts ***!
  \******************************************************/
/*! exports provided: LoanScenarioRequest */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanScenarioRequest", function() { return LoanScenarioRequest; });
var LoanScenarioRequest = /** @class */ (function () {
    function LoanScenarioRequest() {
    }
    return LoanScenarioRequest;
}());



/***/ }),

/***/ "./src/app/loan/models/loan-scenario-response.ts":
/*!*******************************************************!*\
  !*** ./src/app/loan/models/loan-scenario-response.ts ***!
  \*******************************************************/
/*! exports provided: LoanScenarioResponse, LoanScenarioSchedule, ScheduleDetails */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanScenarioResponse", function() { return LoanScenarioResponse; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanScenarioSchedule", function() { return LoanScenarioSchedule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ScheduleDetails", function() { return ScheduleDetails; });
var LoanScenarioResponse = /** @class */ (function () {
    function LoanScenarioResponse() {
    }
    return LoanScenarioResponse;
}());

var LoanScenarioSchedule = /** @class */ (function () {
    function LoanScenarioSchedule() {
    }
    return LoanScenarioSchedule;
}());

var ScheduleDetails = /** @class */ (function () {
    function ScheduleDetails() {
    }
    return ScheduleDetails;
}());



/***/ }),

/***/ "./src/app/loan/services/loan-service.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/loan/services/loan-service.service.ts ***!
  \*******************************************************/
/*! exports provided: LoanService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanService", function() { return LoanService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var LoanService = /** @class */ (function () {
    function LoanService(http) {
        this.http = http;
        this.serviceUrl = 'debt'; // URL to web api
    }
    /** POST: calculate */
    LoanService.prototype.calculate = function (loanRequest) {
        return this.http.post(this.serviceUrl, loanRequest, httpOptions);
    };
    /**
     * Handle Http operation that failed.
     * Let the app continue.
     * @param operation - name of the operation that failed
     * @param result - optional value to return as the observable result
     */
    LoanService.prototype.handleError = function (operation, result) {
        var _this = this;
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            // TODO: send the error to remote logging infrastructure
            console.error(error); // log to console instead
            // TODO: better job of transforming error for user consumption
            _this.log(operation + " failed: " + error.message);
            // Let the app keep running by returning an empty result.
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(result);
        };
    };
    /** Log a HeroService message with the MessageService */
    LoanService.prototype.log = function (message) {
        console.log(message);
    };
    LoanService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], LoanService);
    return LoanService;
}());



/***/ })

}]);
//# sourceMappingURL=loan-loan-module.js.map