(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["savings-savings-module"],{

/***/ "./src/app/savings/models/savings-scenario-request.ts":
/*!************************************************************!*\
  !*** ./src/app/savings/models/savings-scenario-request.ts ***!
  \************************************************************/
/*! exports provided: SavingsScenarioRequest */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SavingsScenarioRequest", function() { return SavingsScenarioRequest; });
var SavingsScenarioRequest = /** @class */ (function () {
    function SavingsScenarioRequest() {
    }
    return SavingsScenarioRequest;
}());



/***/ }),

/***/ "./src/app/savings/models/savings-scenario-response.ts":
/*!*************************************************************!*\
  !*** ./src/app/savings/models/savings-scenario-response.ts ***!
  \*************************************************************/
/*! exports provided: SavingsScenarioResponse, SavingsScenarioSchedule, ScheduleDetails */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SavingsScenarioResponse", function() { return SavingsScenarioResponse; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SavingsScenarioSchedule", function() { return SavingsScenarioSchedule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ScheduleDetails", function() { return ScheduleDetails; });
var SavingsScenarioResponse = /** @class */ (function () {
    function SavingsScenarioResponse() {
    }
    return SavingsScenarioResponse;
}());

var SavingsScenarioSchedule = /** @class */ (function () {
    function SavingsScenarioSchedule() {
    }
    return SavingsScenarioSchedule;
}());

var ScheduleDetails = /** @class */ (function () {
    function ScheduleDetails() {
    }
    return ScheduleDetails;
}());



/***/ }),

/***/ "./src/app/savings/saving-scenario-inputs/saving-scenario-inputs.component.css":
/*!*************************************************************************************!*\
  !*** ./src/app/savings/saving-scenario-inputs/saving-scenario-inputs.component.css ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/savings/saving-scenario-inputs/saving-scenario-inputs.component.html":
/*!**************************************************************************************!*\
  !*** ./src/app/savings/saving-scenario-inputs/saving-scenario-inputs.component.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-card>\n  <mat-card-header>\n    <mat-card-title>{{scenarioTitle}}</mat-card-title>\n  </mat-card-header>\n  <mat-form-field class=\"test-full-width\">\n    <mat-label>Goal Amount</mat-label>\n    <input matInput placeholder=\"Future Value Amount\" type=\"number\" [(ngModel)]=\"savingsInput.goalTargetAmount\">\n    <span matPrefix>$&nbsp;</span>\n  </mat-form-field>\n\n  <mat-form-field class=\"test-full-width\">\n    <mat-label>Start Amount Reg.</mat-label>\n    <input matInput placeholder=\"Start Amount Reg\" type=\"number\" [(ngModel)]=\"savingsInput.initialRegAccValue\">\n    <span matPrefix>$&nbsp;</span>\n  </mat-form-field>\n\n  <mat-form-field class=\"test-full-width\">\n    <mat-label>Start Amount Non-Reg.</mat-label>\n    <input matInput placeholder=\"Start Amount Non-Reg\" type=\"number\" [(ngModel)]=\"savingsInput.initialNonRegAccValue\">\n    <span matPrefix>$&nbsp;</span>\n  </mat-form-field>\n\n  <mat-form-field class=\"test-full-width\">\n    <mat-label>Periodic Contribution Reg.</mat-label>\n    <input matInput placeholder=\"Periodic Contribution Reg\" type=\"number\" [(ngModel)]=\"savingsInput.contributionRegAcc\">\n    <span matPrefix>$&nbsp;</span>\n  </mat-form-field>\n\n  <mat-form-field class=\"test-full-width\">\n    <mat-label>Periodic Contribution Non-Reg.</mat-label>\n    <input matInput placeholder=\"Periodic Contribution Non-Reg.\" type=\"number\" [(ngModel)]=\"savingsInput.contributionNonRegAcc\">\n    <span matPrefix>$&nbsp;</span>\n  </mat-form-field>\n\n  <mat-form-field class=\"test-full-width\">\n    <mat-label>Goal Target Year (YYYY)</mat-label>\n    <input matInput [matDatepicker]=\"picker\" [(ngModel)]=\"savingsInput.futureDate\" placeholder=\"Choose a target year (YYYY)\">\n    <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\n    <mat-datepicker #picker startView=\"multi-year\" (yearSelected)=\"chosenYearHandler($event, picker)\"></mat-datepicker>\n  </mat-form-field>\n\n  <mat-form-field class=\"test-full-width\" appearance=\"fill\">\n    <mat-label>Interest Rate Reg.</mat-label>\n    <input matInput placeholder=\"Interest Rate Reg\" type=\"number\" [(ngModel)]=\"savingsInput.interestRateRegAcc\">\n    <span matSuffix>%&nbsp;</span>\n  </mat-form-field>\n\n  <mat-form-field class=\"test-full-width\" appearance=\"fill\">\n    <mat-label>Interest Rate Non-Reg.</mat-label>\n    <input matInput placeholder=\"Interest Rate Non-Reg\" type=\"number\" [(ngModel)]=\"savingsInput.interestRateNonRegAcc\">\n    <span matSuffix>%&nbsp;</span>\n  </mat-form-field>\n\n  <mat-form-field class=\"test-full-width\" appearance=\"fill\">\n    <mat-label>Inflation Rate</mat-label>\n    <input matInput placeholder=\"Inflation Rate\" type=\"number\" [(ngModel)]=\"savingsInput.inflationRate\">\n    <span matSuffix>%&nbsp;</span>\n  </mat-form-field>\n\n  <mat-form-field class=\"test-full-width\" appearance=\"fill\">\n    <mat-label>Tax Rate</mat-label>\n    <input matInput placeholder=\"Tax Rate\" type=\"number\" [(ngModel)]=\"savingsInput.taxRate\">\n    <span matSuffix>%&nbsp;</span>\n  </mat-form-field>\n\n  <mat-form-field class=\"test-full-width\" appearance=\"fill\">\n    <mat-label>TFSA Contribution Limit</mat-label>\n    <input matInput placeholder=\"TFSA Contrib. Limit\" type=\"number\" [(ngModel)]=\"savingsInput.contributionLimitRegAcc\">\n    <span matPrefix>$&nbsp;</span>\n  </mat-form-field>\n\n  <mat-checkbox [(ngModel)]=\"savingsInput.computeInflationRegAcc\">Adj Reg Contrib Growth</mat-checkbox>\n  <hr>\n  <mat-checkbox [(ngModel)]=\"savingsInput.computeInflationNonRegAcc\">Adj Non-Reg Contrib Growth</mat-checkbox>\n  <hr>\n\n</mat-card>"

/***/ }),

/***/ "./src/app/savings/saving-scenario-inputs/saving-scenario-inputs.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/savings/saving-scenario-inputs/saving-scenario-inputs.component.ts ***!
  \************************************************************************************/
/*! exports provided: MY_FORMATS, SavingScenarioInputsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MY_FORMATS", function() { return MY_FORMATS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SavingScenarioInputsComponent", function() { return SavingScenarioInputsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material-moment-adapter */ "./node_modules/@angular/material-moment-adapter/esm5/material-moment-adapter.es5.js");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/core */ "./node_modules/@angular/material/esm5/core.es5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var MY_FORMATS = {
    parse: {
        dateInput: 'YYYY',
    },
    display: {
        dateInput: 'YYYY',
        monthYearLabel: 'YYYY',
        dateA11yLabel: 'LL',
        monthYearA11yLabel: 'YYYY',
    },
};
var SavingScenarioInputsComponent = /** @class */ (function () {
    function SavingScenarioInputsComponent() {
        this.toComputeOptimal = false;
        this.savingsInput = {
            'id': 1,
            'computeOptimalSolution': false,
            // 'lumpSum': 0.00,
            // 'contributionAmount': 1000.00,
            'compoundingFrequency': 'ANNUAL',
            'futureDate': '2028-08-31',
            'goalTargetAmount': 60000.00,
            'interestRateRegAcc': 5.0,
            'interestRateNonRegAcc': 5.0,
            'inflationRate': 1.0,
            'taxRate': 28.0,
            'computeInflationNonRegAcc': false,
            'computeInflationRegAcc': false,
            'contributionLimitRegAcc': 5000.00,
            'contributionNonRegAcc': 1000.0,
            'contributionRegAcc': 5000.0,
            'initialRegAccValue': 50.00,
            'initialNonRegAccValue': 100.00
        };
    }
    SavingScenarioInputsComponent.prototype.ngOnInit = function () {
        this.scenarioTitle = '';
        if (this.scenarioId === 0) {
            this.scenarioTitle += 'Current Scenario';
        }
        else {
            this.scenarioTitle += 'Alternative Scenario ' + this.scenarioId;
        }
    };
    SavingScenarioInputsComponent.prototype.ngOnChanges = function (changes) {
    };
    SavingScenarioInputsComponent.prototype.chosenYearHandler = function (normalizedYear, datepicker) {
        this.savingsInput.futureDate = normalizedYear.toISOString();
        datepicker.close();
    };
    SavingScenarioInputsComponent.prototype.prepareScenarioInputsList = function () {
        var savingScenarioList = [];
        this.savingsInput.id = this.scenarioId;
        this.savingsInput.futureDate = moment__WEBPACK_IMPORTED_MODULE_1__(this.savingsInput.futureDate).format('YYYY-MM-DD');
        savingScenarioList.push(this.savingsInput);
        if (this.toComputeOptimal) {
            var savingsInputsToComputeOptimalSolution = Object.assign({}, this.savingsInput);
            savingsInputsToComputeOptimalSolution.computeOptimalSolution = true;
            savingScenarioList.push(savingsInputsToComputeOptimalSolution);
        }
        return savingScenarioList;
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], SavingScenarioInputsComponent.prototype, "toComputeOptimal", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Number)
    ], SavingScenarioInputsComponent.prototype, "scenarioId", void 0);
    SavingScenarioInputsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-saving-scenario-inputs',
            template: __webpack_require__(/*! ./saving-scenario-inputs.component.html */ "./src/app/savings/saving-scenario-inputs/saving-scenario-inputs.component.html"),
            styles: [__webpack_require__(/*! ./saving-scenario-inputs.component.css */ "./src/app/savings/saving-scenario-inputs/saving-scenario-inputs.component.css")],
            providers: [
                { provide: _angular_material_core__WEBPACK_IMPORTED_MODULE_3__["DateAdapter"], useClass: _angular_material_moment_adapter__WEBPACK_IMPORTED_MODULE_2__["MomentDateAdapter"], deps: [_angular_material_core__WEBPACK_IMPORTED_MODULE_3__["MAT_DATE_LOCALE"]] },
                { provide: _angular_material_core__WEBPACK_IMPORTED_MODULE_3__["MAT_DATE_FORMATS"], useValue: MY_FORMATS },
            ],
        }),
        __metadata("design:paramtypes", [])
    ], SavingScenarioInputsComponent);
    return SavingScenarioInputsComponent;
}());



/***/ }),

/***/ "./src/app/savings/savings-calculator/savings-calculator.component.css":
/*!*****************************************************************************!*\
  !*** ./src/app/savings/savings-calculator/savings-calculator.component.css ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".mat-card-content {\n    font-size: 16px;\n    \n}\n.mat-card-content.div {\n    padding-bottom: 5px;\n    text-align: left;\n}\n.mat-card-title {\n    font-size: 18px;\n}"

/***/ }),

/***/ "./src/app/savings/savings-calculator/savings-calculator.component.html":
/*!******************************************************************************!*\
  !*** ./src/app/savings/savings-calculator/savings-calculator.component.html ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--The content below is only a placeholder and can be replaced.-->\n<mat-horizontal-stepper>\n  <mat-step label=\"Your Scenarios\">\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start stretch\" fxLayoutGap>\n      <div fxLayout=\"row\" fxFill fxLayoutAlign=\"space-around\" fxLayoutGap fxFlex=\"80%\">\n\n        <app-saving-scenario-inputs [scenarioId]=\"0\" [toComputeOptimal]=\"true\"></app-saving-scenario-inputs>\n\n        <app-saving-scenario-inputs [scenarioId]=\"1\"></app-saving-scenario-inputs>\n\n        <app-saving-scenario-inputs [scenarioId]=\"2\"></app-saving-scenario-inputs>\n      </div>\n      <div>\n        <button mat-button matStepperNext (click)=\"calculate()\">Calculate</button>\n      </div>\n    </div>\n\n  </mat-step>\n  <mat-step label=\"Plans for Your Scenarios\">\n    <div fxLayout=\"row\" fxFill fxLayoutGap fxLayoutAlign=\"center stretch\" *ngIf=\"results\">\n      <mat-card>\n        <mat-card-header>\n          <mat-card-title>.</mat-card-title>\n        </mat-card-header>\n        <mat-card-content>\n          <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n            Target Years\n          </div>\n          <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n            Target Amount\n          </div>\n          <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n            Registered Account Contribution\n          </div>\n          <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n            Non-Registered Account Contribution\n          </div>\n          <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n            Registered Account Assets\n          </div>\n          <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n            Non-Registered Account Assets\n          </div>\n          <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n            Registered Account Return Rate\n          </div>\n          <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n            Non-Registered Account Return Rate\n          </div>\n          <mat-divider inset=\"true\"></mat-divider>\n          <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n            Final Amount\n          </div>\n          <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n            (Deficit)/Surplus\n          </div>\n        </mat-card-content>\n      </mat-card>\n      <app-scenario-result *ngFor=\"let request of savingsInputRequest; let i = index\" \n        [scenarioResult]=\"results[i]\" \n        [scenarioRequest]=\"request\"\n        (selectedScenarioResult)=\"selectScenarioResult($event)\">\n      </app-scenario-result>\n    </div>\n\n    <div>\n      <button mat-button matStepperPrevious>Back to Update Scenarios</button>\n    </div>\n  </mat-step>\n  <mat-step label=\"Schedules for Your Selected Scenario\">\n    <div fxLayout=\"row\" fxFill fxLayoutGap fxLayoutAlign=\"center stretch\" *ngIf=\"scheduleData\">\n      <div fxFlex fxFill>\n        <app-savings-results [schedules]=\"scheduleData.schedule\" [results]=\"scheduleData\" [resultTitle]=\"scheduleTitle\">\n        </app-savings-results>\n      </div>\n    </div>\n\n    <div>\n      <button mat-button matStepperPrevious>Back to Scenario Plans</button>\n    </div>\n  </mat-step>\n</mat-horizontal-stepper>"

/***/ }),

/***/ "./src/app/savings/savings-calculator/savings-calculator.component.ts":
/*!****************************************************************************!*\
  !*** ./src/app/savings/savings-calculator/savings-calculator.component.ts ***!
  \****************************************************************************/
/*! exports provided: SavingsCalculatorComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SavingsCalculatorComponent", function() { return SavingsCalculatorComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_savings_service_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/savings-service.service */ "./src/app/savings/services/savings-service.service.ts");
/* harmony import */ var _saving_scenario_inputs_saving_scenario_inputs_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../saving-scenario-inputs/saving-scenario-inputs.component */ "./src/app/savings/saving-scenario-inputs/saving-scenario-inputs.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var SavingsCalculatorComponent = /** @class */ (function () {
    function SavingsCalculatorComponent(service) {
        this.service = service;
    }
    SavingsCalculatorComponent.prototype.ngOnInit = function () {
    };
    SavingsCalculatorComponent.prototype.calculate = function () {
        var _this = this;
        this.savingsInputRequest = [].concat.apply([], this.savingScenarioInputsList.map(function (savingScenarioInputs) { return savingScenarioInputs.prepareScenarioInputsList(); }));
        this.service.calculate(this.savingsInputRequest).subscribe(function (data) {
            _this.results = data;
        });
    };
    SavingsCalculatorComponent.prototype.selectScenarioResult = function (result) {
        this.scheduleData = result['scenario'];
        this.scheduleTitle = result['title'];
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChildren"])(_saving_scenario_inputs_saving_scenario_inputs_component__WEBPACK_IMPORTED_MODULE_2__["SavingScenarioInputsComponent"]),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["QueryList"])
    ], SavingsCalculatorComponent.prototype, "savingScenarioInputsList", void 0);
    SavingsCalculatorComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-savings-calculator',
            template: __webpack_require__(/*! ./savings-calculator.component.html */ "./src/app/savings/savings-calculator/savings-calculator.component.html"),
            styles: [__webpack_require__(/*! ./savings-calculator.component.css */ "./src/app/savings/savings-calculator/savings-calculator.component.css")]
        }),
        __metadata("design:paramtypes", [_services_savings_service_service__WEBPACK_IMPORTED_MODULE_1__["SavingsServiceService"]])
    ], SavingsCalculatorComponent);
    return SavingsCalculatorComponent;
}());



/***/ }),

/***/ "./src/app/savings/savings-results/savings-results.component.css":
/*!***********************************************************************!*\
  !*** ./src/app/savings/savings-results/savings-results.component.css ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/savings/savings-results/savings-results.component.html":
/*!************************************************************************!*\
  !*** ./src/app/savings/savings-results/savings-results.component.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-card>\n  <h3>Key Result Values for {{resultTitle}}</h3>\n  <table>\n    <tr><td class=\"result-title-cell\">Target Amount ($):</td><td>{{results.targetAmount | number:'1.0-0'}}</td></tr>\n    <tr><td class=\"result-title-cell\">Computed Amount ($):</td><td>{{results.finalAmount | number:'1.0-0'}}</td></tr>\n    <tr><td class=\"result-title-cell\">{{results.goalDelta > 0 && 'Deficit($):' || 'Surplus($):'}}</td><td>{{Math.abs(results.goalDelta) | number:'1.0-0'}}</td></tr>\n    <tr><td class=\"result-title-cell\">Reg. Contribution Required ($):</td><td>{{results.regContributionAmount | number:'1.0-0'}}</td></tr>\n    <tr><td class=\"result-title-cell\">Non-Reg. Contribution Required ($):</td><td>{{results.nonRegContributionAmount | number:'1.0-0'}}</td></tr>\n    <tr><td class=\"result-title-cell\">Target End Year:</td><td>{{currentYear + results.targetEndYear}}</td></tr>\n  </table>\n</mat-card>\n\n<mat-card>\n  <h3>Result Schedules</h3>\n  <table mat-table [dataSource]=\"schedules\" class=\"test-full-width\">\n\n      <!--- Note that these columns can be defined in any order.\n            The actual rendered columns are set as a property on the row definition\" -->\n    \n      <!-- Position Column -->\n      <ng-container matColumnDef=\"year\">\n        <th mat-header-cell *matHeaderCellDef> Year </th>\n        <td class=\"result-cell\" mat-cell *matCellDef=\"let record\"> {{record.year}} </td>\n      </ng-container>\n          \n      <!-- Weight Column -->\n      <ng-container matColumnDef=\"registeredAccountContribution\">\n        <th mat-header-cell *matHeaderCellDef> Reg. Contrib. Growth ($)</th>\n        <td class=\"result-cell\" mat-cell *matCellDef=\"let record\">\n          <app-schedule-info [startingBalance]=\"record.registeredAccountContribution.startingBalance\"\n            [contribution]=\"record.registeredAccountContribution.contribution\"\n            [interest]=\"record.registeredAccountContribution.interest\"\n            [afterTaxInterest]=\"record.registeredAccountContribution.afterTaxInterest\"\n            [endingBalance]=\"record.registeredAccountContribution.endingBalance\"\n            >\n          </app-schedule-info>\n        </td>\n      </ng-container>\n\n      <ng-container matColumnDef=\"nonRegisteredAccountContribution\">\n        <th mat-header-cell *matHeaderCellDef> Non-Reg. Contrib. Growth ($)</th>\n        <td class=\"result-cell\" mat-cell *matCellDef=\"let record\">\n          <app-schedule-info [startingBalance]=\"record.nonRegisteredAccountContribution.startingBalance\"\n            [contribution]=\"record.nonRegisteredAccountContribution.contribution\"\n            [interest]=\"record.nonRegisteredAccountContribution.interest\"\n            [afterTaxInterest]=\"record.nonRegisteredAccountContribution.afterTaxInterest\"\n            [endingBalance]=\"record.nonRegisteredAccountContribution.endingBalance\"\n            >\n          </app-schedule-info>\n        </td>\n      </ng-container>\n      \n      <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n      <tr mat-row *matRowDef=\"let row; columns: displayedColumns;\"></tr>\n    </table>\n</mat-card>\n"

/***/ }),

/***/ "./src/app/savings/savings-results/savings-results.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/savings/savings-results/savings-results.component.ts ***!
  \**********************************************************************/
/*! exports provided: SavingsResultsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SavingsResultsComponent", function() { return SavingsResultsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var SavingsResultsComponent = /** @class */ (function () {
    function SavingsResultsComponent() {
        this.displayedColumns = ['year', 'registeredAccountContribution', 'nonRegisteredAccountContribution'];
        this.Math = Math;
    }
    SavingsResultsComponent.prototype.ngOnInit = function () {
        this.currentYear = moment__WEBPACK_IMPORTED_MODULE_1__().year();
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], SavingsResultsComponent.prototype, "schedules", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], SavingsResultsComponent.prototype, "results", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], SavingsResultsComponent.prototype, "resultTitle", void 0);
    SavingsResultsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-savings-results',
            template: __webpack_require__(/*! ./savings-results.component.html */ "./src/app/savings/savings-results/savings-results.component.html"),
            styles: [__webpack_require__(/*! ./savings-results.component.css */ "./src/app/savings/savings-results/savings-results.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], SavingsResultsComponent);
    return SavingsResultsComponent;
}());



/***/ }),

/***/ "./src/app/savings/savings-routing.module.ts":
/*!***************************************************!*\
  !*** ./src/app/savings/savings-routing.module.ts ***!
  \***************************************************/
/*! exports provided: SavingsRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SavingsRoutingModule", function() { return SavingsRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _savings_calculator_savings_calculator_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./savings-calculator/savings-calculator.component */ "./src/app/savings/savings-calculator/savings-calculator.component.ts");


var routes = [
    {
        path: '',
        component: _savings_calculator_savings_calculator_component__WEBPACK_IMPORTED_MODULE_1__["SavingsCalculatorComponent"]
    }
];
var SavingsRoutingModule = _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes);


/***/ }),

/***/ "./src/app/savings/savings.module.ts":
/*!*******************************************!*\
  !*** ./src/app/savings/savings.module.ts ***!
  \*******************************************/
/*! exports provided: SavingsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SavingsModule", function() { return SavingsModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _material_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../material.module */ "./src/app/material.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _savings_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./savings-routing.module */ "./src/app/savings/savings-routing.module.ts");
/* harmony import */ var _saving_scenario_inputs_saving_scenario_inputs_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./saving-scenario-inputs/saving-scenario-inputs.component */ "./src/app/savings/saving-scenario-inputs/saving-scenario-inputs.component.ts");
/* harmony import */ var _savings_calculator_savings_calculator_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./savings-calculator/savings-calculator.component */ "./src/app/savings/savings-calculator/savings-calculator.component.ts");
/* harmony import */ var _savings_results_savings_results_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./savings-results/savings-results.component */ "./src/app/savings/savings-results/savings-results.component.ts");
/* harmony import */ var _scenario_result_scenario_result_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./scenario-result/scenario-result.component */ "./src/app/savings/scenario-result/scenario-result.component.ts");
/* harmony import */ var _schedule_info_schedule_info_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./schedule-info/schedule-info.component */ "./src/app/savings/schedule-info/schedule-info.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};












var SavingsModule = /** @class */ (function () {
    function SavingsModule() {
    }
    SavingsModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _material_module__WEBPACK_IMPORTED_MODULE_2__["MaterialComponentsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_5__["FlexLayoutModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"],
                _savings_routing_module__WEBPACK_IMPORTED_MODULE_6__["SavingsRoutingModule"]
            ],
            declarations: [
                _saving_scenario_inputs_saving_scenario_inputs_component__WEBPACK_IMPORTED_MODULE_7__["SavingScenarioInputsComponent"],
                _savings_calculator_savings_calculator_component__WEBPACK_IMPORTED_MODULE_8__["SavingsCalculatorComponent"],
                _savings_results_savings_results_component__WEBPACK_IMPORTED_MODULE_9__["SavingsResultsComponent"],
                _scenario_result_scenario_result_component__WEBPACK_IMPORTED_MODULE_10__["ScenarioResultComponent"],
                _schedule_info_schedule_info_component__WEBPACK_IMPORTED_MODULE_11__["ScheduleInfoComponent"]
            ],
            exports: [
                _savings_calculator_savings_calculator_component__WEBPACK_IMPORTED_MODULE_8__["SavingsCalculatorComponent"]
            ]
        })
    ], SavingsModule);
    return SavingsModule;
}());



/***/ }),

/***/ "./src/app/savings/scenario-result/scenario-result.component.css":
/*!***********************************************************************!*\
  !*** ./src/app/savings/scenario-result/scenario-result.component.css ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".mat-card-content {\n    font-size: 16px;\n    \n}\n.mat-card-content.div {\n    padding-bottom: 5px;\n    text-align: left;\n}\n.mat-card-title {\n    font-size: 18px;\n}"

/***/ }),

/***/ "./src/app/savings/scenario-result/scenario-result.component.html":
/*!************************************************************************!*\
  !*** ./src/app/savings/scenario-result/scenario-result.component.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-card>\n  <mat-card-header>\n    <mat-card-title><button mat-button matStepperNext (click)=\"select()\"><span >{{scenarioTitle}}</span></button></mat-card-title>\n  </mat-card-header>\n  <mat-card-content fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start stretch\" fxLayoutGap>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n      <span>{{scenarioResult.targetEndYear}} years</span>\n    </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n      <span>${{scenarioResult.targetAmount | number:'1.0-0'}}</span>\n    </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n      <span>${{scenarioResult.regContributionAmount | number:'1.0-0'}}</span>\n    </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n      <span>${{scenarioResult.nonRegContributionAmount | number:'1.0-0'}}</span>\n    </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n      <span>${{scenarioRequest.initialRegAccValue}}</span>\n    </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n      <span>${{scenarioRequest.initialNonRegAccValue}}</span>\n    </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n        <span>{{scenarioRequest.interestRateRegAcc}}%</span>\n      </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n      <span>{{scenarioRequest.interestRateNonRegAcc}}%</span>\n    </div>\n    <mat-divider inset=\"true\"></mat-divider>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n      <span>${{scenarioResult.finalAmount | number:'1.0-0'}}</span>\n    </div>\n    <div *ngIf=\"scenarioResult.goalDelta < 0; else showDeficit\" fxLayout=\"column\" fxFill fxLayoutAlign=\"space-around start\" fxLayoutGap>\n      <span>${{Math.abs(scenarioResult.goalDelta) | number:'1.0-0'}}</span>\n    </div>\n    <ng-template #showDeficit>\n      <span>(${{Math.abs(scenarioResult.goalDelta) | number:'1.0-0'}})</span>\n    </ng-template>\n  </mat-card-content>\n</mat-card>"

/***/ }),

/***/ "./src/app/savings/scenario-result/scenario-result.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/savings/scenario-result/scenario-result.component.ts ***!
  \**********************************************************************/
/*! exports provided: ScenarioResultComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ScenarioResultComponent", function() { return ScenarioResultComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _models_savings_scenario_response__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../models/savings-scenario-response */ "./src/app/savings/models/savings-scenario-response.ts");
/* harmony import */ var _models_savings_scenario_request__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../models/savings-scenario-request */ "./src/app/savings/models/savings-scenario-request.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var ScenarioResultComponent = /** @class */ (function () {
    function ScenarioResultComponent() {
        this.selectedScenarioResult = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.Math = Math;
    }
    ScenarioResultComponent.prototype.ngOnInit = function () {
        if (this.scenarioResult.id === 0) {
            this.scenarioTitle = 'Current Scenario';
        }
        else {
            this.scenarioTitle = 'Alternative Scenario ' + this.scenarioResult.id;
        }
        if (this.scenarioRequest.computeOptimalSolution) {
            this.scenarioTitle = 'Optimal Solution';
        }
    };
    ScenarioResultComponent.prototype.select = function () {
        this.selectedScenarioResult.emit({ scenario: this.scenarioResult, title: this.scenarioTitle });
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", _models_savings_scenario_response__WEBPACK_IMPORTED_MODULE_1__["SavingsScenarioResponse"])
    ], ScenarioResultComponent.prototype, "scenarioResult", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", _models_savings_scenario_request__WEBPACK_IMPORTED_MODULE_2__["SavingsScenarioRequest"])
    ], ScenarioResultComponent.prototype, "scenarioRequest", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], ScenarioResultComponent.prototype, "selectedScenarioResult", void 0);
    ScenarioResultComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-scenario-result',
            template: __webpack_require__(/*! ./scenario-result.component.html */ "./src/app/savings/scenario-result/scenario-result.component.html"),
            styles: [__webpack_require__(/*! ./scenario-result.component.css */ "./src/app/savings/scenario-result/scenario-result.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], ScenarioResultComponent);
    return ScenarioResultComponent;
}());



/***/ }),

/***/ "./src/app/savings/schedule-info/schedule-info.component.css":
/*!*******************************************************************!*\
  !*** ./src/app/savings/schedule-info/schedule-info.component.css ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/savings/schedule-info/schedule-info.component.html":
/*!********************************************************************!*\
  !*** ./src/app/savings/schedule-info/schedule-info.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap fxFlex=\"30%\">\n  <!-- Starting balance-->\n  <div fxLayout=\"row\" fxFill fxLayoutAlign=\"center end\">\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\">\n      <span>Starting Balance:</span>\n    </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\">\n      <span>{{startingBalance | currency}}</span>\n    </div>\n  </div>\n  <!-- contribution-->\n  <div fxLayout=\"row\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n        <span>Contribution:</span>\n      </div>\n      <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n        <span>{{contribution | currency}}</span>\n      </div>\n    </div>\n  <!-- interest-->\n  <div fxLayout=\"row\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>Interest:</span>\n    </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>{{interest | currency}}</span>\n    </div>\n  </div>\n  <!-- After tax interest-->\n  <div fxLayout=\"row\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>After Tax Interest:</span>\n    </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>{{afterTaxInterest | currency}}</span>\n    </div>\n  </div>\n\n  <!-- Ending balance-->\n  <div fxLayout=\"row\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>Ending Balance:</span>\n    </div>\n    <div fxLayout=\"column\" fxFill fxLayoutAlign=\"center end\" fxLayoutGap>\n      <span>{{endingBalance | currency}}</span>\n    </div>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/savings/schedule-info/schedule-info.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/savings/schedule-info/schedule-info.component.ts ***!
  \******************************************************************/
/*! exports provided: ScheduleInfoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ScheduleInfoComponent", function() { return ScheduleInfoComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ScheduleInfoComponent = /** @class */ (function () {
    function ScheduleInfoComponent() {
    }
    ScheduleInfoComponent.prototype.ngOnInit = function () {
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], ScheduleInfoComponent.prototype, "startingBalance", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], ScheduleInfoComponent.prototype, "interest", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], ScheduleInfoComponent.prototype, "afterTaxInterest", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], ScheduleInfoComponent.prototype, "endingBalance", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], ScheduleInfoComponent.prototype, "contribution", void 0);
    ScheduleInfoComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-schedule-info',
            template: __webpack_require__(/*! ./schedule-info.component.html */ "./src/app/savings/schedule-info/schedule-info.component.html"),
            styles: [__webpack_require__(/*! ./schedule-info.component.css */ "./src/app/savings/schedule-info/schedule-info.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], ScheduleInfoComponent);
    return ScheduleInfoComponent;
}());



/***/ }),

/***/ "./src/app/savings/services/savings-service.service.ts":
/*!*************************************************************!*\
  !*** ./src/app/savings/services/savings-service.service.ts ***!
  \*************************************************************/
/*! exports provided: SavingsServiceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SavingsServiceService", function() { return SavingsServiceService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var SavingsServiceService = /** @class */ (function () {
    function SavingsServiceService(http) {
        this.http = http;
        this.serviceUrl = 'saving'; // URL to web api
    }
    /** POST: calculate */
    SavingsServiceService.prototype.calculate = function (savingsRequest) {
        return this.http.post(this.serviceUrl, savingsRequest, httpOptions);
    };
    /**
     * Handle Http operation that failed.
     * Let the app continue.
     * @param operation - name of the operation that failed
     * @param result - optional value to return as the observable result
     */
    SavingsServiceService.prototype.handleError = function (operation, result) {
        var _this = this;
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            // TODO: send the error to remote logging infrastructure
            console.error(error); // log to console instead
            // TODO: better job of transforming error for user consumption
            _this.log(operation + " failed: " + error.message);
            // Let the app keep running by returning an empty result.
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(result);
        };
    };
    /** Log a HeroService message with the MessageService */
    SavingsServiceService.prototype.log = function (message) {
        console.log(message);
    };
    SavingsServiceService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], SavingsServiceService);
    return SavingsServiceService;
}());



/***/ })

}]);
//# sourceMappingURL=savings-savings-module.js.map